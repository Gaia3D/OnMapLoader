====================
OnMap Loader Plugin 
온맵 로더 플러그인
====================

This program is an assistant tool that allows you to read OnMap PDF files distributed by the Korea National Geographic Information Insititute(NGII) from QGIS and display them in the correct geographical location. 
This program has been developed as part of the 'Development of the Spatial information quality inspection System' project by NGII. 

이 프로그램은 대한민국 국토지리정보원에서 배포하는 온맵 PDF 파일을 QGIS에서 읽어 올바른 지리적 위치에 보일 수 있게 해 주는 보조도구 입니다. 
이 프로그램은 국토지리정보원의 '공간정보 품질검사 시스템 개발'사업의 일부로 개발되었습니다.

* Homepage
  https://gaia3d.github.io/OnMapLoader/
  
* Source Repogitory 
  https://github.com/Gaia3D/OnMapLoader

* Author
  BJ Jang at Gaia3D
    
* License
  GPL2